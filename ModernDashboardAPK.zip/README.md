# Modern Dashboard Android App

A Kotlin + Jetpack Compose Android application inspired by the supplied dashboard reference.

## Features
- Live 24-hour clock and Vietnamese date
- Vietnamese lunar date calculation (UTC+7)
- Current week strip
- Battery percentage and battery temperature
- Android memory (RAM) usage
- Internal shared storage usage
- Manual refresh button

## Build
Requires JDK 17, Android SDK Platform 35, Build Tools 35.0.0, and Gradle 8.9.
Run: `gradle assembleDebug`
APK: `app/build/outputs/apk/debug/app-debug.apk`

The temperature shown is the battery temperature reported by Android, not the CPU temperature.
RAM and storage values are estimates/reported system values and may differ from the phone's Settings screen.
