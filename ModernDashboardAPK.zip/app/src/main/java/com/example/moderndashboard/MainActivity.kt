package com.example.moderndashboard

import android.app.ActivityManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.StatFs
import android.text.format.DateFormat
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BatteryFull
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Storage
import androidx.compose.material.icons.filled.Thermostat
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import kotlin.math.roundToInt

private val pageBg = Color(0xFF718191)
private val panel = Color(0xFF111A30)
private val tile = Color(0xFF202A40)
private val muted = Color(0xFFAAB5CC)
private val green = Color(0xFF37C96B)
private val orange = Color(0xFFFFA51F)
private val purple = Color(0xFF9B83FF)
private val teal = Color(0xFF20C7B5)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { DashboardScreen(this) }
    }
}

data class DeviceStats(
    val battery: Int = 0,
    val batteryTemp: Float = 0f,
    val ramUsed: Long = 0,
    val ramTotal: Long = 0,
    val storageUsed: Long = 0,
    val storageTotal: Long = 0
)

@Composable
fun DashboardScreen(context: Context) {
    var now by remember { mutableStateOf(Calendar.getInstance()) }
    var stats by remember { mutableStateOf(readStats(context)) }

    LaunchedEffect(Unit) {
        while (true) {
            now = Calendar.getInstance()
            stats = readStats(context)
            delay(1000)
        }
    }

    val time = SimpleDateFormat("HH:mm", Locale("vi", "VN")).format(now.time)
    val dateText = SimpleDateFormat("EEEE, dd 'tháng' M", Locale("vi", "VN")).format(now.time)
        .replaceFirstChar { it.uppercase(Locale("vi", "VN")) }
    val lunar = lunarDate(now.get(Calendar.DAY_OF_MONTH), now.get(Calendar.MONTH) + 1, now.get(Calendar.YEAR))

    Surface(modifier = Modifier.fillMaxSize(), color = pageBg) {
        BoxWithConstraints(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            val compact = maxWidth < 600.dp
            Column(
                modifier = Modifier
                    .fillMaxWidth(if (compact) 0.96f else 0.92f)
                    .background(panel, RoundedCornerShape(if (compact) 28.dp else 38.dp))
                    .padding(if (compact) 18.dp else 28.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                if (compact) {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text(time, color = Color.White, fontSize = 68.sp,
                                    fontWeight = FontWeight.Bold, lineHeight = 72.sp)
                                Text(dateText, color = Color.White, fontSize = 17.sp,
                                    fontWeight = FontWeight.Bold)
                                Text("Âm lịch: ${lunar.first} tháng ${lunar.second}", color = muted,
                                    fontSize = 16.sp)
                            }
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text(Build.MODEL.ifBlank { "Android" }, color = muted,
                                    fontSize = 12.sp, fontWeight = FontWeight.SemiBold,
                                    textAlign = TextAlign.Center)
                                IconButton(onClick = { stats = readStats(context); now = Calendar.getInstance() }) {
                                    Icon(Icons.Default.Refresh, contentDescription = "Làm mới", tint = Color(0xFF8DAEFF))
                                }
                            }
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Box(Modifier.weight(1f)) {
                                StatTile("PIN", "${stats.battery}%", " ", stats.battery / 100f, green, Icons.Default.BatteryFull)
                            }
                            Box(Modifier.weight(1f)) {
                                StatTile("NHIỆT ĐỘ", "${"%.1f".format(Locale.US, stats.batteryTemp)}°C",
                                    if (stats.batteryTemp < 38f) "Mát" else "Ấm",
                                    (stats.batteryTemp / 60f).coerceIn(0f, 1f), orange, Icons.Default.Thermostat)
                            }
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Box(Modifier.weight(1f)) {
                                StatTile("RAM", "${percent(stats.ramUsed, stats.ramTotal)}%",
                                    "${gb(stats.ramUsed)}/${gb(stats.ramTotal)}", ratio(stats.ramUsed, stats.ramTotal), purple, Icons.Default.Memory)
                            }
                            Box(Modifier.weight(1f)) {
                                StatTile("Ổ CỨNG", "${percent(stats.storageUsed, stats.storageTotal)}%",
                                    "${gb(stats.storageTotal - stats.storageUsed)} trống", ratio(stats.storageUsed, stats.storageTotal), teal, Icons.Default.Storage)
                            }
                        }
                    }
                } else {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(time, color = Color.White, fontSize = 104.sp,
                                fontWeight = FontWeight.Bold, lineHeight = 108.sp)
                            Spacer(Modifier.height(10.dp))
                            Text(dateText, color = Color.White, fontSize = 25.sp,
                                fontWeight = FontWeight.Bold)
                            Text("Âm lịch: ${lunar.first} tháng ${lunar.second}", color = muted, fontSize = 24.sp)
                        }
                        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(Build.MODEL.ifBlank { "Thiết bị Android" }, color = muted,
                                    fontSize = 16.sp, fontWeight = FontWeight.SemiBold,
                                    modifier = Modifier.weight(1f), textAlign = TextAlign.Center)
                                IconButton(onClick = { stats = readStats(context); now = Calendar.getInstance() }) {
                                    Icon(Icons.Default.Refresh, contentDescription = "Làm mới", tint = Color(0xFF8DAEFF))
                                }
                            }
                            StatTile("PIN", "${stats.battery}%", " ", stats.battery / 100f, green, Icons.Default.BatteryFull)
                            StatTile("NHIỆT ĐỘ", "${"%.1f".format(Locale.US, stats.batteryTemp)}°C",
                                if (stats.batteryTemp < 38f) "Mát" else "Ấm",
                                (stats.batteryTemp / 60f).coerceIn(0f, 1f), orange, Icons.Default.Thermostat)
                            StatTile("RAM", "${percent(stats.ramUsed, stats.ramTotal)}%",
                                "${gb(stats.ramUsed)}/${gb(stats.ramTotal)}", ratio(stats.ramUsed, stats.ramTotal), purple, Icons.Default.Memory)
                            StatTile("Ổ CỨNG", "${percent(stats.storageUsed, stats.storageTotal)}%",
                                "${gb(stats.storageTotal - stats.storageUsed)} trống", ratio(stats.storageUsed, stats.storageTotal), teal, Icons.Default.Storage)
                        }
                    }
                }
                WeekStrip(now)
            }
        }
    }
}

@Composable
fun StatTile(title: String, value: String, detail: String, progress: Float, color: Color,
             icon: androidx.compose.ui.graphics.vector.ImageVector) {
    Column(
        Modifier.fillMaxWidth().background(tile, RoundedCornerShape(22.dp)).padding(horizontal = 12.dp, vertical = 10.dp),
        verticalArrangement = Arrangement.spacedBy(5.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(icon, contentDescription = null, tint = color, modifier = Modifier.size(18.dp))
            Spacer(Modifier.width(7.dp))
            Text(title, color = muted, fontWeight = FontWeight.Bold, fontSize = 13.sp)
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(value, color = Color.White, fontSize = 19.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.weight(1f))
            Text(detail, color = muted, fontSize = 11.sp)
        }
        LinearProgressIndicator(progress = { progress.coerceIn(0f, 1f) },
            modifier = Modifier.fillMaxWidth().height(7.dp),
            color = color, trackColor = Color(0xFF3A4358))
    }
}

@Composable
fun WeekStrip(current: Calendar) {
    val start = (current.clone() as Calendar).apply {
        val day = get(Calendar.DAY_OF_WEEK)
        add(Calendar.DAY_OF_MONTH, -(day - Calendar.MONDAY + 7) % 7)
    }
    val days = (0..6).map { offset -> (start.clone() as Calendar).apply { add(Calendar.DAY_OF_MONTH, offset) } }
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        days.forEach { day ->
            val selected = day.get(Calendar.DAY_OF_YEAR) == current.get(Calendar.DAY_OF_YEAR) &&
                    day.get(Calendar.YEAR) == current.get(Calendar.YEAR)
            val labels = listOf("CN", "T2", "T3", "T4", "T5", "T6", "T7")
            val label = labels[day.get(Calendar.DAY_OF_WEEK) - 1]
            Column(
                Modifier.weight(1f).background(if (selected) Color(0xFFA9B6D0) else Color.Transparent,
                    RoundedCornerShape(22.dp)).padding(vertical = 8.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(label, color = if (selected) Color.White else muted, fontSize = 15.sp)
                Text("${day.get(Calendar.DAY_OF_MONTH)}", color = Color.White, fontSize = 23.sp, fontWeight = FontWeight.Bold)
                Text("${lunarDate(day.get(Calendar.DAY_OF_MONTH), day.get(Calendar.MONTH) + 1, day.get(Calendar.YEAR)).first}",
                    color = if (selected) Color.White else muted, fontSize = 12.sp)
            }
        }
    }
}

fun readStats(context: Context): DeviceStats {
    val batteryIntent = context.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
    val level = batteryIntent?.getIntExtra(BatteryManager.EXTRA_LEVEL, 0) ?: 0
    val scale = batteryIntent?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
    val temp = (batteryIntent?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) ?: 0) / 10f

    val am = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
    val memory = ActivityManager.MemoryInfo()
    am.getMemoryInfo(memory)
    val totalRam = memory.totalMem
    val usedRam = (totalRam - memory.availMem).coerceAtLeast(0)

    val stat = StatFs(Environment.getDataDirectory().path)
    val totalStorage = stat.totalBytes
    val freeStorage = stat.availableBytes
    return DeviceStats(
        battery = if (scale > 0) (level * 100f / scale).roundToInt() else 0,
        batteryTemp = temp,
        ramUsed = usedRam,
        ramTotal = totalRam,
        storageUsed = totalStorage - freeStorage,
        storageTotal = totalStorage
    )
}

fun percent(used: Long, total: Long): Int =
    if (total <= 0) 0 else (used * 100.0 / total).roundToInt().coerceIn(0, 100)

fun ratio(used: Long, total: Long): Float =
    if (total <= 0) 0f else (used.toDouble() / total).toFloat().coerceIn(0f, 1f)

fun gb(bytes: Long): String = String.format(Locale.US, "%.1fG", bytes / (1024.0 * 1024 * 1024))

// Vietnamese lunar calendar conversion, UTC+7.
fun lunarDate(dd: Int, mm: Int, yy: Int): Pair<Int, Int> {
    val dayNumber = jdFromDate(dd, mm, yy)
    val k = Math.floor((dayNumber - 2415021.076998695) / 29.530588853).toInt()
    var monthStart = getNewMoonDay(k + 1, 7)
    if (monthStart > dayNumber) monthStart = getNewMoonDay(k, 7)
    var a11 = getLunarMonth11(yy, 7)
    var b11 = a11
    val lunarYear: Int
    if (a11 >= monthStart) {
        lunarYear = yy
        a11 = getLunarMonth11(yy - 1, 7)
    } else {
        lunarYear = yy + 1
        b11 = getLunarMonth11(yy + 1, 7)
    }
    val lunarDay = dayNumber - monthStart + 1
    val diff = ((monthStart - a11) / 29).toInt()
    var lunarMonth = diff + 11
    var lunarLeap = 0
    if (b11 - a11 > 365) {
        val leapMonthDiff = getLeapMonthOffset(a11, 7)
        if (diff >= leapMonthDiff) {
            lunarMonth = diff + 10
            if (diff == leapMonthDiff) lunarLeap = 1
        }
    }
    if (lunarMonth > 12) lunarMonth -= 12
    val year = if (lunarMonth >= 11 && diff < 4) lunarYear - 1 else lunarYear
    return Pair(lunarDay, lunarMonth)
}

fun jdFromDate(d: Int, m: Int, y: Int): Int {
    val a = (14 - m) / 12
    val yy = y + 4800 - a
    val mm = m + 12 * a - 3
    var jd = d + (153 * mm + 2) / 5 + 365 * yy + yy / 4 - yy / 100 + yy / 400 - 32045
    if (jd < 2299161) jd = d + (153 * mm + 2) / 5 + 365 * yy + yy / 4 - 32083
    return jd
}
fun newMoon(k: Int): Double {
    val t = k / 1236.85
    val t2 = t * t
    val t3 = t2 * t
    val dr = Math.PI / 180
    var jd1 = 2415020.75933 + 29.53058868 * k + 0.0001178 * t2 - 0.000000155 * t3
    jd1 += 0.00033 * Math.sin((166.56 + 132.87 * t - 0.009173 * t2) * dr)
    val m = 359.2242 + 29.10535608 * k - 0.0000333 * t2 - 0.00000347 * t3
    val mpr = 306.0253 + 385.81691806 * k + 0.0107306 * t2 + 0.00001236 * t3
    val f = 21.2964 + 390.67050646 * k - 0.0016528 * t2 - 0.00000239 * t3
    var c1 = (0.1734 - 0.000393 * t) * Math.sin(m * dr) + 0.0021 * Math.sin(2 * m * dr)
    c1 -= 0.4068 * Math.sin(mpr * dr) + 0.0161 * Math.sin(2 * mpr * dr)
    c1 -= 0.0004 * Math.sin(3 * mpr * dr)
    c1 += 0.0104 * Math.sin(2 * f * dr) - 0.0051 * Math.sin((m + mpr) * dr)
    c1 -= 0.0074 * Math.sin((m - mpr) * dr) - 0.0004 * Math.sin((2 * f + m) * dr)
    c1 -= 0.0006 * Math.sin((2 * f - m) * dr) + 0.0010 * Math.sin((2 * f + mpr) * dr)
    c1 += 0.0005 * Math.sin((2 * f - mpr) * dr)
    val delta = if (t < -11) 0.001 + 0.000839 * t + 0.0002261 * t2 - 0.00000845 * t3 - 0.000000081 * t * t3
                else -0.000278 + 0.000265 * t + 0.000262 * t2
    return jd1 + c1 - delta
}
fun getNewMoonDay(k: Int, timeZone: Int): Int = Math.floor(newMoon(k) + 0.5 + timeZone / 24.0).toInt()
fun sunLongitude(jdn: Int, timeZone: Int): Int {
    val t = (jdn - 2451545.5 - timeZone / 24.0) / 36525
    val t2 = t * t
    val dr = Math.PI / 180
    val m = 357.52910 + 35999.05030 * t - 0.0001559 * t2 - 0.00000048 * t * t2
    val l0 = 280.46645 + 36000.76983 * t + 0.0003032 * t2
    var dl = (1.914600 - 0.004817 * t - 0.000014 * t2) * Math.sin(dr * m)
    dl += (0.019993 - 0.000101 * t) * Math.sin(2 * dr * m) + 0.000290 * Math.sin(3 * dr * m)
    var l = l0 + dl
    l *= dr
    l -= Math.PI * 2 * Math.floor(l / (Math.PI * 2))
    return Math.floor(l / Math.PI * 6).toInt()
}
fun getSunLongitude(dayNumber: Int, timeZone: Int): Int = sunLongitude(dayNumber, timeZone)
fun getLunarMonth11(yy: Int, timeZone: Int): Int {
    val off = jdFromDate(31, 12, yy) - 2415021
    val k = Math.floor(off / 29.530588853).toInt()
    var nm = getNewMoonDay(k, timeZone)
    val sunLong = getSunLongitude(nm, timeZone)
    if (sunLong >= 9) nm = getNewMoonDay(k - 1, timeZone)
    return nm
}
fun getLeapMonthOffset(a11: Int, timeZone: Int): Int {
    val k = Math.floor(0.5 + (a11 - 2415021.076998695) / 29.530588853).toInt()
    var i = 1
    var last = 0
    var arc = getSunLongitude(getNewMoonDay(k + i, timeZone), timeZone)
    do {
        last = arc
        i++
        arc = getSunLongitude(getNewMoonDay(k + i, timeZone), timeZone)
    } while (arc != last && i < 14)
    return i - 1
}
