# Modern Dashboard Widget (Kotlin)

Widget Android màn hình chính bằng Kotlin + RemoteViews.

## Chức năng
- Đồng hồ, ngày dương lịch và lịch âm Việt Nam UTC+7.
- Pin, nhiệt độ pin, RAM, dung lượng bộ nhớ trong.
- Lịch 7 ngày, tô màu ngày hiện tại.
- Nhấn biểu tượng ↻ hoặc widget để cập nhật thủ công.

## Build APK trên máy tính
1. Cài Android Studio và JDK 17.
2. Mở thư mục `ModernDashboardWidget`.
3. Chờ Gradle Sync hoàn tất.
4. Chọn Build > Build Bundle(s) / APK(s) > Build APK(s).
5. APK: `app/build/outputs/apk/debug/app-debug.apk`.

## Build APK chỉ bằng điện thoại qua GitHub
1. Tạo tài khoản tại https://github.com.
2. Tạo repository mới tên `ModernDashboardWidget`.
3. Giải nén ZIP và tải toàn bộ nội dung trong thư mục dự án lên repository. Giữ nguyên thư mục `.github/workflows`.
4. Mở tab Actions trong repository.
5. Chọn workflow `Build Android APK` > `Run workflow`.
6. Chờ chạy xong, mở lần chạy mới nhất, kéo xuống mục Artifacts.
7. Tải `ModernDashboard-debug-apk`, giải nén và lấy `app-debug.apk`.
8. Mở APK trên điện thoại để cài. Nếu Android hỏi, cho phép trình duyệt hoặc ứng dụng quản lý tệp cài ứng dụng từ nguồn đó.

## Thêm widget
1. Cài APK.
2. Nhấn giữ vùng trống trên màn hình chính.
3. Chọn Widget > Modern Dashboard.
4. Kéo widget ra màn hình và kéo rộng để xem đủ thông tin.

## Lưu ý
- Android giới hạn cập nhật định kỳ của widget; cấu hình hiện tại là 30 phút. Chạm widget hoặc ↻ để làm mới ngay.
- Đồng hồ dùng `TextClock` để tự đổi theo phút; thông số thiết bị cập nhật định kỳ 30 phút hoặc khi nhấn làm mới.
- Nhiệt độ là nhiệt độ pin, không phải CPU.
- RAM là ước tính bộ nhớ hệ thống đang sử dụng. Dung lượng là phân vùng dữ liệu người dùng.
- Đây là APK debug để thử nghiệm, chưa phải bản phát hành Play Store.
