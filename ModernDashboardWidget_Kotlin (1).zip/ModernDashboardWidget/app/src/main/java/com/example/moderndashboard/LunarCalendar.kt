package com.example.moderndashboard

import kotlin.math.floor
import kotlin.math.sin

data class LunarDate(val day: Int, val month: Int, val year: Int, val leap: Boolean)

object LunarCalendar {
    private fun jd(dd: Int, mm: Int, yy: Int): Int {
        val a = floor((14 - mm) / 12.0).toInt()
        val y = yy + 4800 - a
        val m = mm + 12 * a - 3
        var result = dd + floor((153 * m + 2) / 5.0).toInt() + 365 * y + floor(y / 4.0).toInt() - floor(y / 100.0).toInt() + floor(y / 400.0).toInt() - 32045
        if (result < 2299161) result = dd + floor((153 * m + 2) / 5.0).toInt() + 365 * y + floor(y / 4.0).toInt() - 32083
        return result
    }
    private fun newMoon(k: Int): Double {
        val t = k / 1236.85; val t2 = t * t; val t3 = t2 * t; val dr = Math.PI / 180.0
        var v = 2415020.75933 + 29.53058868 * k + 0.0001178 * t2 - 0.000000155 * t3
        v += 0.00033 * sin((166.56 + 132.87 * t - 0.009173 * t2) * dr)
        val m = 359.2242 + 29.10535608 * k - 0.0000333 * t2 - 0.00000347 * t3
        val mp = 306.0253 + 385.81691806 * k + 0.0107306 * t2 + 0.00001236 * t3
        val f = 21.2964 + 390.67050646 * k - 0.0016528 * t2 - 0.00000239 * t3
        val c = (0.1734 - 0.000393 * t) * sin(m * dr) + 0.0021 * sin(2 * m * dr) - 0.4068 * sin(mp * dr) + 0.0161 * sin(2 * mp * dr) - 0.0004 * sin(3 * mp * dr) + 0.0104 * sin(2 * f * dr) - 0.0051 * sin((m + mp) * dr) - 0.0074 * sin((m - mp) * dr) + 0.0004 * sin((2 * f + m) * dr) - 0.0004 * sin((2 * f - m) * dr) - 0.0006 * sin((2 * f + mp) * dr) + 0.0010 * sin((2 * f - mp) * dr) + 0.0005 * sin((2 * mp + m) * dr)
        val delta = if (t < -11) 0.001 + 0.000839 * t + 0.0002261 * t2 - 0.00000845 * t3 - 0.000000081 * t * t3 else -0.000278 + 0.000265 * t + 0.000262 * t2
        return v + c - delta
    }
    private fun newMoonDay(k: Int, tz: Double) = floor(newMoon(k) + 0.5 + tz / 24.0).toInt()
    private fun sunLongitude(day: Int, tz: Double): Int {
        val t = (day - 0.5 - tz / 24.0 - 2451545.0) / 36525.0; val t2 = t * t; val dr = Math.PI / 180.0
        val m = 357.52910 + 35999.05030 * t - 0.0001559 * t2 - 0.00000048 * t * t2
        val l0 = 280.46645 + 36000.76983 * t + 0.0003032 * t2
        var dl = (1.914600 - 0.004817 * t - 0.000014 * t2) * sin(dr * m)
        dl += (0.019993 - 0.000101 * t) * sin(2 * dr * m); dl += 0.000290 * sin(3 * dr * m)
        var l = (l0 + dl) * dr; l -= Math.PI * 2 * floor(l / (Math.PI * 2))
        return floor(l / Math.PI * 6).toInt()
    }
    private fun month11(year: Int, tz: Double): Int {
        val off = jd(31, 12, year) - 2415021; val k = floor(off / 29.530588853).toInt()
        var nm = newMoonDay(k, tz); if (sunLongitude(nm, tz) >= 9) nm = newMoonDay(k - 1, tz); return nm
    }
    private fun leapOffset(a11: Int, tz: Double): Int {
        val k = floor(0.5 + (a11 - 2415021.076998695) / 29.530588853).toInt(); var last = 0; var i = 1
        var arc = sunLongitude(newMoonDay(k + i, tz), tz)
        do { last = arc; i++; arc = sunLongitude(newMoonDay(k + i, tz), tz) } while (arc != last && i < 14)
        return i - 1
    }
    fun convert(dd: Int, mm: Int, yy: Int, tz: Double = 7.0): LunarDate {
        val dayNumber = jd(dd, mm, yy); val k = floor((dayNumber - 2415021.076998695) / 29.530588853).toInt()
        var monthStart = newMoonDay(k + 1, tz); if (monthStart > dayNumber) monthStart = newMoonDay(k, tz)
        var a11 = month11(yy, tz); var b11 = a11; val lunarYear: Int
        if (a11 >= monthStart) { lunarYear = yy; a11 = month11(yy - 1, tz) } else { lunarYear = yy + 1; b11 = month11(yy + 1, tz) }
        val lunarDay = dayNumber - monthStart + 1; val diff = floor((monthStart - a11) / 29.0).toInt()
        var leap = false; var lunarMonth = diff + 11
        if (b11 - a11 > 365) { val leapDiff = leapOffset(a11, tz); if (diff >= leapDiff) { lunarMonth = diff + 10; if (diff == leapDiff) leap = true } }
        if (lunarMonth > 12) lunarMonth -= 12
        var adjustedYear = lunarYear; if (lunarMonth >= 11 && diff < 4) adjustedYear--
        return LunarDate(lunarDay, lunarMonth, adjustedYear, leap)
    }
}
