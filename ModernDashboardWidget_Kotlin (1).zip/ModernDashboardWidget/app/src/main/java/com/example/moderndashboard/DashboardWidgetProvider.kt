package com.example.moderndashboard

import android.app.ActivityManager
import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import android.os.Environment
import android.os.StatFs
import android.widget.RemoteViews
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale
import kotlin.math.roundToInt

class DashboardWidgetProvider : AppWidgetProvider() {
    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) {
        ids.forEach { updateOne(context, manager, it) }
    }

    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)
        if (intent.action == ACTION_REFRESH) {
            val manager = AppWidgetManager.getInstance(context)
            val ids = manager.getAppWidgetIds(ComponentName(context, DashboardWidgetProvider::class.java))
            ids.forEach { updateOne(context, manager, it) }
        }
    }

    companion object {
        private const val ACTION_REFRESH = "com.example.moderndashboard.REFRESH"

        private fun updateOne(context: Context, manager: AppWidgetManager, widgetId: Int) {
            val views = RemoteViews(context.packageName, R.layout.widget_dashboard)
            val now = Calendar.getInstance()
            val date = now.time

            val dateText = SimpleDateFormat("EEEE, dd 'tháng' M", Locale("vi", "VN"))
                .format(date).replaceFirstChar { if (it.isLowerCase()) it.titlecase(Locale("vi", "VN")) else it.toString() }
            views.setTextViewText(R.id.date_text, dateText)

            val lunar = LunarCalendar.convert(now.get(Calendar.DAY_OF_MONTH), now.get(Calendar.MONTH) + 1, now.get(Calendar.YEAR))
            views.setTextViewText(R.id.lunar_text, "Âm lịch: ${lunar.day} tháng ${lunar.month}" + if (lunar.leap) " nhuận" else "")
            views.setTextViewText(R.id.device_model, android.os.Build.MODEL ?: android.os.Build.DEVICE)

            val batteryManager = context.getSystemService(Context.BATTERY_SERVICE) as BatteryManager
            val battery = batteryManager.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY).coerceIn(0, 100)
            val batteryStatus = context.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
            val temp = (batteryStatus?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) ?: 0) / 10f

            val activityManager = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
            val memory = ActivityManager.MemoryInfo()
            activityManager.getMemoryInfo(memory)
            val totalRam = memory.totalMem
            val usedRam = (totalRam - memory.availMem).coerceAtLeast(0L)
            val ramPercent = if (totalRam > 0) (usedRam * 100L / totalRam).toInt().coerceIn(0, 100) else 0

            val stat = StatFs(Environment.getDataDirectory().path)
            val totalStorage = stat.totalBytes
            val freeStorage = stat.availableBytes
            val storagePercent = if (totalStorage > 0) ((totalStorage - freeStorage) * 100L / totalStorage).toInt().coerceIn(0, 100) else 0
            val freeGb = freeStorage / (1024L * 1024L * 1024L)

            views.setTextViewText(R.id.battery_value, "$battery%")
            views.setProgressBar(R.id.battery_progress, 100, battery, false)
            views.setTextViewText(R.id.temp_value, if (temp > 0f) String.format(Locale.US, "%.1f°C", temp) else "--°C")
            views.setProgressBar(R.id.temp_progress, 100, temp.roundToInt().coerceIn(0, 100), false)

            val totalRamGb = totalRam / (1024.0 * 1024.0 * 1024.0)
            val usedRamGb = usedRam / (1024.0 * 1024.0 * 1024.0)
            views.setTextViewText(R.id.ram_value, "$ramPercent%")
            views.setTextViewText(R.id.ram_title, String.format(Locale.US, "RAM  %.1f/%.0fG", usedRamGb, totalRamGb))
            views.setProgressBar(R.id.ram_progress, 100, ramPercent, false)
            views.setTextViewText(R.id.storage_value, "$storagePercent%")
            views.setTextViewText(R.id.storage_title, "BỘ NHỚ  ${freeGb}G trống")
            views.setProgressBar(R.id.storage_progress, 100, storagePercent, false)

            val labels = arrayOf("T2", "T3", "T4", "T5", "T6", "T7", "CN")
            val mondayOffset = (now.get(Calendar.DAY_OF_WEEK) + 5) % 7
            val monday = (now.clone() as Calendar).apply { add(Calendar.DAY_OF_MONTH, -mondayOffset) }
            val dayIds = intArrayOf(R.id.day0, R.id.day1, R.id.day2, R.id.day3, R.id.day4, R.id.day5, R.id.day6)
            for (i in 0..6) {
                val day = (monday.clone() as Calendar).apply { add(Calendar.DAY_OF_MONTH, i) }
                val ld = LunarCalendar.convert(day.get(Calendar.DAY_OF_MONTH), day.get(Calendar.MONTH) + 1, day.get(Calendar.YEAR))
                val id = dayIds[i]
                views.setTextViewText(intArrayOf(R.id.day0_name, R.id.day1_name, R.id.day2_name, R.id.day3_name, R.id.day4_name, R.id.day5_name, R.id.day6_name)[i], labels[i])
                views.setTextViewText(intArrayOf(R.id.day0_number, R.id.day1_number, R.id.day2_number, R.id.day3_number, R.id.day4_number, R.id.day5_number, R.id.day6_number)[i], day.get(Calendar.DAY_OF_MONTH).toString())
                views.setTextViewText(intArrayOf(R.id.day0_lunar, R.id.day1_lunar, R.id.day2_lunar, R.id.day3_lunar, R.id.day4_lunar, R.id.day5_lunar, R.id.day6_lunar)[i], ld.day.toString())
                val isToday = day.get(Calendar.YEAR) == now.get(Calendar.YEAR) && day.get(Calendar.DAY_OF_YEAR) == now.get(Calendar.DAY_OF_YEAR)
                views.setInt(intArrayOf(R.id.day0_container, R.id.day1_container, R.id.day2_container, R.id.day3_container, R.id.day4_container, R.id.day5_container, R.id.day6_container)[i], "setBackgroundResource", if (isToday) R.drawable.day_selected else 0)
            }

            val refresh = Intent(context, DashboardWidgetProvider::class.java).apply { action = ACTION_REFRESH }
            val pending = PendingIntent.getBroadcast(context, widgetId, refresh, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
            views.setOnClickPendingIntent(R.id.refresh, pending)
            views.setOnClickPendingIntent(R.id.widget_root, pending)
            manager.updateAppWidget(widgetId, views)
        }
    }
}
